<section class="breadcrumbs">
    <div class="content-wrapper">
        <?php
        if ( function_exists('yoast_breadcrumb') ) {
            yoast_breadcrumb();
        }
        ?>
    </div>
</section>
