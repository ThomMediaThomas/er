<?php /* Template Name: Kids corner */ ?>

<?php get_header(); ?>

	<main role="main" class="kids-page">

		<?php get_template_part('/elements/hero'); ?>
		<?php get_template_part('/elements/custom-blocks'); ?>

	</main>

<?php get_footer(); ?>
