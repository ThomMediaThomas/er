<?php get_header(); ?>

<main role="main">

	<?php get_template_part('/elements/hero'); ?>

	<?php get_template_part('/elements/custom-blocks'); ?>

</main>

<?php get_footer(); ?>
