<?php
//moved contents to accommodation-booker.php because of lack of option (or talent) to share global vars between template parts
?>