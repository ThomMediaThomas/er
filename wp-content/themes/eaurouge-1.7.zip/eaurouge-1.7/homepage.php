<?php /* Template Name: Homepage */ ?>
<?php get_header(); ?>

<main role="main">

	<?php get_template_part('/elements/hero'); ?>
	<?php get_template_part('/elements/custom-blocks'); ?>
	<?php get_template_part('/elements/reviews'); ?>

</main>

<?php get_footer(); ?>
